package com.postbook;


import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.model.Property;
import com.model.Status;

import com.model.Users;

import dao.PropertyDAOImpl;
import dao.UserDAOImpl;

@Path("airbnb")
public class MyResource {

//	<------------------User url------------------>

	UserDAOImpl userImpl = new UserDAOImpl();
	PropertyDAOImpl propertyDAOImpl = new PropertyDAOImpl();

	@Path("users/register")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Status addUser(Users user) throws SQLException {
		return userImpl.signUp(user);
	}
	
	
	

	@Path("users/login")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Users loginUser(Users user) throws SQLException {
		return userImpl.signIn(user);
	}

	@Path("properties/all-properties")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Property> viewAllProperties() throws SQLException {
		return propertyDAOImpl.viewAllProperties();
	}
	
//
//	@Path("users/updateUser")
//	@PUT
//	@Consumes(MediaType.APPLICATION_JSON)
//	@Produces(MediaType.APPLICATION_JSON)
//	public Status updateUser(Users user) throws SQLException {
//		return userImpl.updateProfile(user);
//	}



}
