let singedInUserId;
var signedInUser = null;
function addUser() {
  const url = "http://localhost:8080/postbook/webapi/airbnb/users/register";

  const data = {
    userName: document.getElementById("signUpName").value,
    userEmail: document.getElementById("signUpEmail").value,
    userPassword: document.getElementById("signUpPassword").value,
  };
  document.getElementById("signUpName").value = "";
  document.getElementById("signUpEmail").value = "";
  document.getElementById("signUpPassword").value = "";

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => resp.json())
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}

let signedInUserEmail;

function signInUser() {
  const url = "http://localhost:8080/postbook/webapi/airbnb/users/login";

  signedInUserEmail = document.getElementById("signInEmail").value;
  const data = {
    userEmail: document.getElementById("signInEmail").value,
    userPassword: document.getElementById("signInPassword").value,
  };

  document.getElementById("signInEmail").value = "";
  document.getElementById("signInPassword").value = "";

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => {
      if (!resp.ok) {
        throw new Error(`HTTP error! Status: ${resp.status}`);
      }
      return resp.json();
    })
    .then((responseData) => {
      signedInUser = responseData;
      console.log("resdata", responseData);
      singedInUserId = responseData.userId;
    })
    .catch((error) => {
      console.error("Error:", error);

      if (error.response) {
        error.response
          .text()
          .then((text) => console.log("Response text:", text));
      }
    });
}

function generatePropertiesCardsHTML(properties, isMyPropertiesTab) {
  let html = "";

  for (const prop of properties) {
    html += `
           <div class="col-md-4 mt-4">
          <div class="property-card d-flex flex-column h-100">
            <img
              src="${prop.propertyImage}"
              alt="Property Image"
              class="property-image"
            />
            <div class="property-details">
              <div class="property-title">
               ${prop.propertyTitle}
              </div>
              <div class="property-type">Residential</div>
              <div class="property-price"> ${prop.propertyPrice}</div>
              <div class="property-location">Hillside Drive, Hilltop City</div>
              <div class="property-description">
                ${prop.propertyDescription}
              </div>
              <div class="property-city"> ${prop.propertyCity}</div>
              <div class="posted-by">Posted by: ${prop.user.userName}</div>
              <button class="buy-button">Buy</button>
            </div>
          </div>
        </div>
    `;
  }

  return html;
}

function appendPropertiesToContainer(container, properties, isMyPropertiesTab) {
  container.innerHTML = generatePropertiesCardsHTML(properties, isMyPropertiesTab);
}

async function getUser() {
  const url = "http://localhost:8080/postbook/webapi/twitter/users/getUser";
  const data = {
    userEmail: signedInUserEmail,
  };

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`Failed to get user. Status: ${response.status}`);
    }

    const responseData = await response.json();
    return responseData.userId;
  } catch (error) {
    console.error("Error getting user:", error);
    throw error; // Rethrow the error to propagate it
  }
}

async function fetchTweets() {
  try {
    console.log(signedInUserEmail);
    const userId = await getUser();
    console.log(userId);
    const response = await fetch(
      `http://localhost:8080/postbook/webapi/twitter/tweets/myTweet/${userId}`
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch tweets. Status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching tweets:", error);
    throw error; // Rethrow the error to propagate it
  }
}

const tweetsContainer = document.getElementById("tweetsContainer");

async function handleMyTweetsClick() {
  // console.log(signedInUserEmail);
  try {
    const tweetsData = await fetchTweets();
    appendPropertiesToContainer(tweetsContainer, tweetsData, true);
  } catch (error) {
    // Handle errors here, e.g., display an error message to the user
    console.error("Error handling my tweets click:", error);
  }
}

async function fetchAllProperties() {
  try {
    const response = await fetch(
      `http://localhost:8080/postbook/webapi/airbnb/properties/all-properties`
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch properties. Status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching properties:", error);
    throw error; // Rethrow the error to propagate it
  }
}

const feedContainer = document.getElementById("feedContainer");

// ... (other code)

async function handleAllPropertiesClick() {
  try {
    const data = await fetchAllProperties();
    console.log(data);
    appendPropertiesToContainer(feedContainer, data, true); // Use feedContainer instead of tweetsContainer
  } catch (error) {
    console.error("Error handling all properties click:", error);
  }
}

// add tweet

function addTweet() {
  const url = "http://localhost:8080/postbook/webapi/twitter/tweets/add";

  const data = {
    tweetBody: document.getElementById("body").value,
    user: {
      userId: singedInUserId,
    },
  };

  document.getElementById("body").value = "";
  console.log(singedInUserId);

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => {
      handleAllTweetsClick();
      resp.json();
    })
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}

function increaseTweetLike(tweetId) {
  // console.log("new", signedInUser);
  const url = `http://localhost:8080/postbook/webapi/twitter/tweets/likes/${tweetId}`;

  fetch(url, { method: "PUT" })
    .then((resp) => {
      handleAllTweetsClick();
      handleMyTweetsClick();
      resp.json();
    })
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}

function deleteTweet(tweetId) {
  const url = `http://localhost:8080/postbook/webapi/twitter/tweets/deleteTweet/${tweetId}`;

  fetch(url, { method: "DELETE" })
    .then((resp) => {
      handleAllTweetsClick();
      handleMyTweetsClick();
      resp.json();
    })
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}

const profileTweetsContainer = document.getElementById(
  "profileTweetsContainer"
);

async function handleMyProfileTweetsClick() {
  try {
    const tweetsData = await fetchFeedTweets(); // Fetch all tweets instead of user's tweets
    appendPropertiesToContainer(profileTweetsContainer, tweetsData, false); // Use false to indicate it's not the "My Tweets" tab
  } catch (error) {
    // Handle errors here, e.g., display an error message to the user
    console.error("Error handling profile tweets click:", error);
  }
}

function makeEditable(fieldId) {
  const field = document.getElementById(fieldId);
  field.contentEditable = true;
  field.focus();
}

function getProfile() {
  const profileContainer = document.getElementById("profileContainer");
  let html = "";

  html += `
  <!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Your Twitter</a>
    <!-- Add other navigation links or buttons -->
  </div>
</nav>

<!-- Profile Header -->
<div class="container mt-4">
  <div class="row">
    <div class="col-md-3">
      <!-- Profile Image -->
      <img src="${signedInUser.userAvatar}" alt="Profile Image" class="img-fluid rounded-circle profile-image" style="width: 150px; height: 150px;">
    </div>
    <div class="col-md-9">
      <!-- Profile Information -->
      <h2>${signedInUser.userName}</h2>
      <p>${signedInUser.userEmail}</p>
      <p class="editable" id="userBio" onclick="makeEditable('userBio')">${signedInUser.userBio}</p>
      <!-- Add other profile details -->

      <!-- Add Edit button for each editable field -->
      <button class="btn btn-link" onclick="makeEditable('userName')">Edit UserName</button>
      <button class="btn btn-link" onclick="makeEditable('userEmail')">Edit Email</button>
      <!-- Add more buttons as needed -->
    </div>
  </div>
</div>

<!-- Profile Tabs -->
<div class="container mt-4">
  <ul class="nav nav-tabs" id="myTabs" role="tablist">
    <li class="nav-item" role="presentation">
      <li class="nav-link active" id="tweets-tab" data-bs-toggle="tab" href="#tweets" role="tab" aria-controls="tweets"
        aria-selected="true" onclick="handleMyProfileTweetsClick()">Tweets</li>
    </li>
    <li class="nav-item" role="presentation">
      <a class="nav-link" id="media-tab" data-bs-toggle="tab" href="#media" role="tab" aria-controls="media"
        aria-selected="false">Media</a>
    </li>
    <!-- Add more tabs as needed -->
  </ul>

  <div class="tab-content mt-2" id="myTabsContent">
    <!-- Tweets Tab -->
    <div class="tab-pane fade show active" id="tweets" role="tabpanel" aria-labelledby="tweets-tab">
      <!-- Display user's tweets here -->
      <div id="profileTweetsContainer"></div>
    </div>

    <!-- Media Tab -->
    <div class="tab-pane fade" id="media" role="tabpanel" aria-labelledby="media-tab">
      <!-- Display user's media content here -->
      <p>Your media content will appear here.</p>
    </div>
    <!-- Add more tab content as needed -->
  </div>
</div>




     
  `;

  profileContainer.innerHTML = html;
}
