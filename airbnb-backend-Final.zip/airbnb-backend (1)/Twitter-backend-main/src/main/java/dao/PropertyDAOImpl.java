package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.model.Property;
import com.model.Users;



public class PropertyDAOImpl implements PropertyDAO{
	
	private Connection connection;

	public PropertyDAOImpl() {
		// TODO Load the DBUtil class
		connection = DBUtil.getConnection();
		System.out.println("User impl's connection= " + connection.hashCode());
	}
	
	
	

	@Override
	public List<Property> viewAllProperties() throws SQLException {
		String sql = "SELECT p.property_id, p.property_title, p.property_location, p.property_city, p.property_price, " +
	             "p.property_description, p.property_image, p.property_type, " +
	             "u.user_id , u.user_name , " +
	             "u.user_email , u.user_address , " +
	             "u.user_mobile , u.user_image  " +
	             "FROM properties AS p " +
	             "INNER JOIN airbnbusers AS u ON u.user_id = p.user_id";

		java.sql.Statement st =  connection.createStatement();

		ResultSet rs =  ((java.sql.Statement) st).executeQuery(sql);
		List<Property> list = new ArrayList<>();
		while (rs.next()) {
			list.add(new Property(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getFloat(5), rs.getString(6), rs.getString(7), rs.getString(8),
					new Users(rs.getInt(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14))));
		}
		return list;
	}
	
	
	@Override
	public List<String> searchPropertiesByCity() throws SQLException {
		String sql = "SELECT DISTINCT property_city FROM properties;";

		java.sql.Statement st =  connection.createStatement();

		ResultSet rs =  ((java.sql.Statement) st).executeQuery(sql);
		List<String> list = new ArrayList<>();
		while (rs.next()) {
			list.add(rs.getString(1));
		}
		return list;
	}

	
	
	
	@Override
	public List<String> searchPropertiesByType() throws SQLException {
		String sql = "SELECT DISTINCT property_type FROM properties;";

		java.sql.Statement st =  connection.createStatement();

		ResultSet rs =  ((java.sql.Statement) st).executeQuery(sql);
		List<String> list = new ArrayList<>();
		while (rs.next()) {
			list.add(rs.getString(1));
		}
		return list;
	}



	@Override
	public Property searchProperty(Property prop) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<Property> viewMyProperty(int id) throws SQLException {
		String sql = "SELECT p.property_id, p.property_title, p.property_location, p.property_city, p.property_price, " +
	             "p.property_description, p.property_image, p.property_type, " +
	             "u.user_id , u.user_name , " +
	             "u.user_email , u.user_address , " +
	             "u.user_mobile , u.user_image  " +
	             "FROM properties AS p " +
	             "INNER JOIN airbnbusers AS u ON u.user_id = p.user_id where u.user_id=?";
		PreparedStatement pst = connection.prepareStatement(sql);

		pst.setInt(1, id);
		ResultSet rs = pst.executeQuery();
		List<Property> list = new ArrayList<>();
		while (rs.next()) {
			list.add(new Property(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getFloat(5), rs.getString(6), rs.getString(7), rs.getString(8),
					new Users(rs.getInt(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14))));
		}
		return list;
	}
	
}
