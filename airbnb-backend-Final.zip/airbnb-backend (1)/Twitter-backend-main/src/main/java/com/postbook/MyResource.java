package com.postbook;


import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.model.Property;
import com.model.Status;

import com.model.Users;

import dao.PropertyDAOImpl;
import dao.UserDAOImpl;

@Path("airbnb")
public class MyResource {

//	<------------------User url------------------>

	UserDAOImpl userImpl = new UserDAOImpl();
	PropertyDAOImpl propertyDAOImpl = new PropertyDAOImpl();

	@Path("users/register")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Status addUser(Users user) throws SQLException {
		return userImpl.signUp(user);
	}
	
	
	

	@Path("users/login")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Users loginUser(Users user) throws SQLException {
		return userImpl.signIn(user);
	}

	@Path("properties/all-properties")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Property> viewAllProperties() throws SQLException {
		return propertyDAOImpl.viewAllProperties();
	}
	
	
	
	@Path("properties/get-all-cities")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<String> searchPropertiesByCity() throws SQLException {
		return propertyDAOImpl.searchPropertiesByCity();
	}
	
	
	@Path("properties/get-all-property-type")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<String> searchPropertiesByType() throws SQLException {
		return propertyDAOImpl.searchPropertiesByType();
	}
	
	@Path("properties/my-properties/{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Property> viewMyProperty(@PathParam("id") int id) throws SQLException {
		return propertyDAOImpl.viewMyProperty(id);
	}
	
	

	@Path("users/updateUser")
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Status updateProfile(Users user) throws SQLException {
		return userImpl.updateProfile(user);
	}

	
	@Path("users/get-user")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Users getUser(Users user) throws SQLException {
		return userImpl.getUser(user);
	}


}
