function addUser() {
  const url = "http://localhost:8080/postbook/webapi/twitter/users/add";

  const data = {
    userName: document.getElementById("signUpName").value,
    userEmail: document.getElementById("signUpEmail").value,
    userPassword: document.getElementById("signUpPassword").value,
  };
  document.getElementById("signUpName").value = "";
  document.getElementById("signUpEmail").value = "";
  document.getElementById("signUpPassword").value = "";

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => resp.json())
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}


function signInUser(){
    const url = "http://localhost:8080/postbook/webapi/twitter/users/login";

    const data = {
      userEmail: document.getElementById("signInEmail").value,
      userPassword: document.getElementById("signInPassword").value,
    };

    document.getElementById("signInEmail").value = "";
    document.getElementById("signInPassword").value = "";

    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((resp) => {
        if (!resp.ok) {
          throw new Error(`HTTP error! Status: ${resp.status}`);
        }
        return resp.json();
      })
      .then((responseData) => console.log(responseData))
      .catch((error) => {
        console.error("Error:", error);
        
        if (error.response) {
          error.response
            .text()
            .then((text) => console.log("Response text:", text));
        }
      });

}

