package com.postbook;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.model.Post;
import com.model.Status;

import dao.PostsDAOImpl;
import dao.TweetDAOImpl;
import dao.User;
import dao.UserDAOImpl;

@Path("twitter")
public class MyResource {
	
	UserDAOImpl userDAOImpl = new UserDAOImpl();
	TweetDAOImpl tweetDAOImpl = new TweetDAOImpl();
	
	
	@Path("user/register")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Status signUp(User user) throws SQLException {
		return userDAOImpl.signUp(user);
	}
	
	@Path("user/login")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public int signIn(String userEmail, String userPassword) throws SQLException {
		return userDAOImpl.signIn(userEmail,userPassword);
	}
	
	
//	
//	@Path("posts/add")
//	@POST
//	@Consumes(MediaType.APPLICATION_JSON)
//	@Produces(MediaType.APPLICATION_JSON)
//	public Post addPost(Post post) {
//		return impl.addPost(post);
//	}
//	
//	@Path("posts/edit")
//	@PUT
//	@Consumes(MediaType.APPLICATION_JSON)
//	@Produces(MediaType.APPLICATION_JSON)
//	public Status editPost(Post post) {
//		return impl.updatePost(post);
//	}
//	
//	@Path("posts/delete/{id}")
//	@DELETE
//	@Produces(MediaType.APPLICATION_JSON)
//	public Status deletePost(@PathParam("id") int id) {
//		return impl.deletePost(new Post(id,"",""));
//	}
//	
}











