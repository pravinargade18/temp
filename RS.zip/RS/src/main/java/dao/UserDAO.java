package dao;

import java.sql.SQLException;
import java.util.List;

import com.model.Status;

public interface UserDAO {

	Status signUp(User user) throws SQLException;

    int signIn(String userEmail, String userPassword) throws SQLException;

    User viewProfile(int uId) throws SQLException;

    int updateProfile(User user) throws SQLException;

}
