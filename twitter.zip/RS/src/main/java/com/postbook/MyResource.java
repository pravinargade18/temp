package com.postbook;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.model.Post;
import com.model.Status;

import dao.PostsDAOImpl;
import dao.Tweet;
import dao.TweetDAOImpl;
import dao.User;
import dao.UserDAOImpl;

@Path("twitter")
public class MyResource {
	
	UserDAOImpl userDAOImpl = new UserDAOImpl();
	TweetDAOImpl tweetDAOImpl = new TweetDAOImpl();
	
	
	@Path("user/register")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Status signUp(User user) throws SQLException {
		return userDAOImpl.signUp(user);
	}
	
	@Path("user/login")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public User signIn(User user) throws SQLException {
		return userDAOImpl.signIn(user);
	}
	
	@Path("user/view-profile")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public User viewProfile(User user) throws SQLException {
		return userDAOImpl.viewProfile(user);
	}
	
	
	@Path("user/tweet/add-tweet")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Status addTweet(Tweet tweet) throws SQLException {
		return tweetDAOImpl.addTweet(tweet);
	}
	
	
	@Path("user/tweets/{userId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Tweet> viewMyTweets(@PathParam("userId") int userId) throws SQLException {
	    return tweetDAOImpl.viewMyTweets(userId);
	}
	
//	
//	@Path("posts/add")
//	@POST
//	@Consumes(MediaType.APPLICATION_JSON)
//	@Produces(MediaType.APPLICATION_JSON)
//	public Post addPost(Post post) {
//		return impl.addPost(post);
//	}
//	
	@Path("user/tweets/update-tweet")
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public  Status updateTweet(Tweet tweet) throws SQLException {
		return tweetDAOImpl.updateTweet(tweet);
	}
//	
	@Path("user/tweets/delete/{id}")
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	public Status deletePost(@PathParam("id") int id) throws SQLException {
		return tweetDAOImpl.deleteTweet(id);
	}
	
	
	@Path("tweets/all")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Tweet> viewAllTweets() throws SQLException {
	    return tweetDAOImpl.viewAllTweets();
	}
	
//	
}











