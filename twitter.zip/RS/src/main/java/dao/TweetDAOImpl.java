package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Status;

public class TweetDAOImpl implements TweetDAO {

    private Connection connection;

    public TweetDAOImpl() {
        connection = DBUtil.getConnection();
    }

    @Override
    public Status addTweet(Tweet tweet) throws SQLException {
    	Status s = new Status();
		int res = -1;
        String query = "INSERT INTO tweet (t_id,t_body, u_id,t_likes) VALUES (?,?,?,?)";
        try (PreparedStatement pst = connection.prepareStatement(query)) {
        	pst.setInt(1, tweet.getTweetId());
            pst.setString(2, tweet.getTweetBody());
            pst.setInt(3, tweet.getUserId());
            pst.setInt(4, tweet.getLikes());
            
            res = pst.executeUpdate();
            s.setQueryStatus((res == 1) ? true : false);
            return s;
        }
    }

    @Override
    public List<Tweet> viewMyTweets(int userId) throws SQLException {
        List<Tweet> tweetList = new ArrayList<>();
        String query = "SELECT * FROM tweet WHERE u_id = ?";
        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setInt(1, userId);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    Tweet tweet = new Tweet(rs.getInt("t_id"),rs.getString("t_body"),rs.getInt("u_id"),rs.getInt("t_likes"));

                    tweetList.add(tweet);
                }
                return tweetList;
            }
        }
    }

    @Override
    public Status updateTweet(Tweet tweet) throws SQLException {
    	Status s = new Status();
		int res = -1;
        String query = "UPDATE tweet SET t_body=? WHERE t_id=?";
        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, tweet.getTweetBody());
            pst.setInt(2, tweet.getTweetId());

            res = pst.executeUpdate();
            s.setQueryStatus((res == 1) ? true : false);
            return s;
        }
    }

    @Override
    public Status deleteTweet(int tId) throws SQLException {
    	Status s = new Status();
		int res = -1;
        String query = "DELETE FROM tweet WHERE t_id=?";
        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setInt(1, tId);

            res = pst.executeUpdate();
            s.setQueryStatus((res == 1) ? true : false);
            return s;
        }
    }

    @Override
    public List<Tweet> viewAllTweets() throws SQLException {
        List<Tweet> tweetList = new ArrayList<>();
        String query = "SELECT t.t_id, t.t_body, t.u_id, t.t_likes, u.u_name, u.u_email, u.u_bio, u.u_avatar " +
                "FROM \"TWEET\" t " +
                "JOIN \"USER\" u ON t.u_id = u.u_id";

        try (PreparedStatement pst = connection.prepareStatement(query)) {
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    System.out.println("User ID: " + rs.getInt("u_id"));
                    System.out.println("User Avatar: " + rs.getString("u_avatar"));
                    System.out.println("User Name: " + rs.getString("u_name"));
                    System.out.println("Tweet ID: " + rs.getInt("t_id"));
                    System.out.println("Tweet Body: " + rs.getString("t_body"));

                    System.out.println("----------------------------");

//                   
                }
                return tweetList;
            }
        }
    }
}
