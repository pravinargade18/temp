package dao;

import java.sql.SQLException;
import java.util.List;

import com.model.Status;

public interface UserDAO {

	Status signUp(User user) throws SQLException;

    User signIn(User user) throws SQLException;

    User viewProfile(User user) throws SQLException;

    int updateProfile(User user) throws SQLException;

}
