package dao;

import java.sql.SQLException;
import java.util.List;

import com.model.Status;

public interface TweetDAO {

	Status addTweet(Tweet tweet) throws SQLException;

	List<Tweet> viewMyTweets(int u_id) throws SQLException;

	Status updateTweet(Tweet tweet) throws SQLException;

	Status deleteTweet(int t_id) throws SQLException;

	List<Tweet> viewAllTweets() throws SQLException;

}