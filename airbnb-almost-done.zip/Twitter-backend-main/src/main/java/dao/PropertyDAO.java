package dao;

import java.sql.SQLException;
import java.util.List;

import com.model.Property;

public interface PropertyDAO {
	Property searchProperty( Property prop) throws SQLException;
	List<Property> viewAllProperties() throws SQLException;
	List<String> searchPropertiesByCity() throws SQLException;
	List<String> searchPropertiesByType() throws SQLException;
	List<Property> viewMyProperty(int id) throws SQLException;
}
