let signedInUserId;
var signedInUser = null;

function addUser() {
  const url = "http://localhost:8080/postbook/webapi/airbnb/users/register";

  const data = {
    userName: document.getElementById("signUpName").value,
    userEmail: document.getElementById("signUpEmail").value,
    userPassword: document.getElementById("signUpPassword").value,
  };
  document.getElementById("signUpName").value = "";
  document.getElementById("signUpEmail").value = "";
  document.getElementById("signUpPassword").value = "";

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => {
      // Check HTTP status code
      if (resp.ok) {
        // Successful response
        return resp.json();
      } else {
        // Unsuccessful response
        throw new Error(`HTTP error! Status: ${resp.status}`);
      }
    })
    .then((responseData) => {
      console.log("Response Data:", responseData);
      // Check response data and show appropriate alerts
      if (responseData && responseData.status === "success") {
        alert("User signed up successfully!");
      } else {
        alert("Failed to sign up. Please try again.");
      }
    })
    .catch((error) => {
      // Show error alert
      alert("An error occurred. Please try again.");
      console.error("Error:", error);
    });
}

let signedInUserEmail;

function signInUser() {
  const url = "http://localhost:8080/postbook/webapi/airbnb/users/login";

  signedInUserEmail = document.getElementById("signInEmail").value;
  const data = {
    userEmail: document.getElementById("signInEmail").value,
    userPassword: document.getElementById("signInPassword").value,
  };

  document.getElementById("signInEmail").value = "";
  document.getElementById("signInPassword").value = "";

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => {
      if (!resp.ok) {
        throw new Error(`HTTP error! Status: ${resp.status}`);
      }
      return resp.json();
    })
    .then((responseData) => {
      signedInUser = responseData;
      console.log("resdata", responseData);
      signedInUserId = responseData.userId;

      // Alert for successful sign-in
      document.getElementById("sign-out-tab").style.display = "list-item";
      document.getElementById("sign-in-tab").style.display = "none";

      // Hide the other tabs
      document.getElementById("sign-up-tab").style.display = "none";
      alert("User signed in successfully!");
    })
    .catch((error) => {
      console.error("Error:", error);

      // Alert for sign-in failure
      alert("Failed to sign in. Please check your credentials and try again.");

      if (error.response) {
        error.response
          .text()
          .then((text) => console.log("Response text:", text));
      }
    });
}

function generatePropertiesCardsHTML(properties, isMyPropertiesTab) {
  let html = "";

  for (const prop of properties) {
    html += `
           <div class="col-md-4 mt-4">
          <div class="property-card d-flex flex-column h-100">
            <img
              src="${prop.propertyImage}"
              alt="Property Image"
              class="property-image"
            />
            <div class="property-details">
              <div class="property-title">
               ${prop.propertyTitle}
              </div>
              <div class="property-type">${prop.propertyType}</div>
              <div class="property-price"> ${prop.propertyPrice}</div>
              <div class="property-location">Hillside Drive, Hilltop City</div>
              <div class="property-description">
                ${prop.propertyDescription}
              </div>
              <div class="property-city"> ${prop.propertyCity}</div>
              <div class="posted-by">Posted by: ${prop.user.userName}</div>
              <button class="buy-button">Buy</button>
            </div>
          </div>
        </div>
    `;
  }

  return html;
}

function appendPropertiesToContainer(container, properties, isMyPropertiesTab) {
  container.innerHTML = generatePropertiesCardsHTML(
    properties,
    isMyPropertiesTab
  );
}

async function getUser() {
  const url = "http://localhost:8080/postbook/webapi/twitter/users/getUser";
  const data = {
    userEmail: signedInUserEmail,
  };

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`Failed to get user. Status: ${response.status}`);
    }

    const responseData = await response.json();
    return responseData.userId;
  } catch (error) {
    console.error("Error getting user:", error);
    throw error; // Rethrow the error to propagate it
  }
}

async function fetchMyProperties() {
  try {
    const response = await fetch(
      `http://localhost:8080/postbook/webapi/airbnb/properties/my-properties/${signedInUserId}`
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch tweets. Status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching tweets:", error);
    throw error; // Rethrow the error to propagate it
  }
}

const propContainer = document.getElementById("tweetsContainer");

async function handleMyPropertiesClick() {
  // console.log(signedInUserEmail);
  try {
    const Data = await fetchMyProperties();
    appendPropertiesToContainer(propContainer, Data, true);
  } catch (error) {
    // Handle errors here, e.g., display an error message to the user
    console.error("Error handling my tweets click:", error);
  }
}

async function fetchAllProperties() {
  try {
    const response = await fetch(
      `http://localhost:8080/postbook/webapi/airbnb/properties/all-properties`
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch properties. Status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching properties:", error);
    throw error; // Rethrow the error to propagate it
  }
}

const feedContainer = document.getElementById("feedContainer");

// ... (other code)

async function handleAllPropertiesClick() {
  try {
    const data = await fetchAllProperties();
    console.log(data);
    appendPropertiesToContainer(feedContainer, data, true); // Use feedContainer instead of tweetsContainer
  } catch (error) {
    console.error("Error handling all properties click:", error);
  }
}

// add tweet

function addTweet() {
  const url = "http://localhost:8080/postbook/webapi/twitter/tweets/add";

  const data = {
    tweetBody: document.getElementById("body").value,
    user: {
      userId: signedInUserId,
    },
  };

  document.getElementById("body").value = "";
  console.log(signedInUserId);

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => {
      handleAllTweetsClick();
      resp.json();
    })
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}

function increaseTweetLike(tweetId) {
  // console.log("new", signedInUser);
  const url = `http://localhost:8080/postbook/webapi/twitter/tweets/likes/${tweetId}`;

  fetch(url, { method: "PUT" })
    .then((resp) => {
      handleAllTweetsClick();
      handleMyTweetsClick();
      resp.json();
    })
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}

function deleteTweet(tweetId) {
  const url = `http://localhost:8080/postbook/webapi/twitter/tweets/deleteTweet/${tweetId}`;

  fetch(url, { method: "DELETE" })
    .then((resp) => {
      handleAllTweetsClick();
      handleMyTweetsClick();
      resp.json();
    })
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}

const profileTweetsContainer = document.getElementById(
  "profileTweetsContainer"
);

async function handleMyProfileTweetsClick() {
  try {
    const tweetsData = await fetchFeedTweets(); // Fetch all tweets instead of user's tweets
    appendPropertiesToContainer(profileTweetsContainer, tweetsData, false); // Use false to indicate it's not the "My Tweets" tab
  } catch (error) {
    // Handle errors here, e.g., display an error message to the user
    console.error("Error handling profile tweets click:", error);
  }
}

async function getSignedInUser() {
  const url = "http://localhost:8080/postbook/webapi/airbnb/users/get-user";

  const data = {
    userId: signedInUserId,
  };

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`Failed to get user. Status: ${response.status}`);
    }

    const responseData = await response.json();
    return responseData;
  } catch (error) {
    console.error("Error getting user:", error);
    throw error; // Rethrow the error to propagate it
  }
}

async function getProfile() {
  const signedInUser = await getSignedInUser();
  console.log(signedInUser);
  const profileContainer = document.getElementById("profileContainer");
  let html = "";

  html += `
 <div class="container mt-4">
      <!-- Profile Info -->
      <div class="card">
        <div class="card-body">
          <div class="row">
            <div class="col-md-3">
              <img src="${signedInUser.userImage}" alt="User Image" class="img-fluid rounded-circle" />
            </div>
            <div class="col-md-9">
              <h2 class="mb-3">${signedInUser.userName}</h2>
              <p>Email: ${signedInUser.userEmail}</p>
              <p>Address: ${signedInUser.userAddress}</p>
              <p>Mobile: ${signedInUser.userMobile}</p>
              <button
                class="btn btn-primary"
                data-toggle="modal"
                data-target="#editProfileModal"
              >
                Edit Profile
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Edit Profile Modal -->
      <div
        class="modal fade"
        id="editProfileModal"
        tabindex="-1"
        role="dialog"
        aria-labelledby="editProfileModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="editProfileModalLabel">
                Edit Profile
              </h5>
              <button
                type="button"
                class="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <!-- Form for editing profile details -->
              <form>
                <div class="form-group">
                  <label for="editUserName">User Name</label>
                  <input
                    type="text"
                    class="form-control"
                    id="editUserName"
                    value="${signedInUser.userName}"
                  />
                </div>
                <div class="form-group">
                  <label for="editUserEmail">Email</label>
                  <input
                    type="email"
                    class="form-control"
                    id="editUserEmail"
                    value="${signedInUser.userEmail}"
                  />
                </div>
                <div class="form-group">
                  <label for="editUserAddress">Address</label>
                  <input
                    type="text"
                    class="form-control"
                    id="editUserAddress"
                    value="${signedInUser.userAddress}"
                  />
                </div>
                <div class="form-group">
                  <label for="editUserMobile">Mobile</label>
                  <input
                    type="text"
                    class="form-control"
                    id="editUserMobile"
                    value="${signedInUser.userMobile}"
                  />
                </div>
                <div class="form-group">
                  <label for="editUserImage">Profile Image URL</label>
                  <input
                    type="text"
                    class="form-control"
                    id="editUserImage"
                    placeholder="Enter image url here..."
                  />
                </div>
               <button type="button" data-dismiss="modal" onclick="updateUserProfile()" class="btn btn-primary">
  Save Changes
</button>
              </form>
            </div>
          </div>
        </div>
      </div>

      <!-- Tabs for My Properties and Favorites -->
      <ul class="nav nav-tabs mt-4">
        <li class="nav-item">
          <button type="button"
            class="nav-link active"
            id="myPropertiesTab"
            data-toggle="tab"
            
            >My Properties</
          >
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            id="favoritesTab"
            data-toggle="tab"
           
            >Favorites</a
          >
        </li>
      </ul>

      <!-- Tab Content -->
      <div class="tab-content mt-2">
        <!-- My Properties Tab Content -->
        <div class="tab-pane fade show active" id="myProperties">
          <!-- Display user's properties here -->
          <p>User's properties will be displayed here.</p>
        </div>

        <!-- Favorites Tab Content -->
        <div class="tab-pane fade" id="favorites">
          <!-- Display user's favorite properties here -->
          <p>User's favorite properties will be displayed here.</p>
        </div>
      </div>
    </div>
  `;

  profileContainer.innerHTML = html;
}

async function updateUserProfile() {
  // console.log("new", signedInUser);

  const url = `http://localhost:8080/postbook/webapi/airbnb/users/updateUser`;

  const data = {
    userId: signedInUserId,
    userName: document.getElementById("editUserName").value,
    userEmail: document.getElementById("editUserEmail").value,
    userAddress: document.getElementById("editUserAddress").value,
    userMobile: document.getElementById("editUserMobile").value,
    userImage: document.getElementById("editUserImage").value,
  };

  fetch(url, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => {
      return resp.json();
    })
    .then((responseData) => {
      getProfile();
    })
    .catch((error) => console.error("Error:", error));
}

// function makeEditable(fieldId) {
//   const field = document.getElementById(fieldId);
//   field.contentEditable = true;
//   field.focus();
// }

// fetching cities

document.addEventListener("DOMContentLoaded", function () {
  fetch(
    "http://localhost:8080/postbook/webapi/airbnb/properties/get-all-cities"
  )
    .then((response) => response.json())
    .then((data) => {
      const cityFilter = document.getElementById("cityFilter");

      data.forEach((city) => {
        const option = document.createElement("option");
        option.value = city;
        option.text = city;
        cityFilter.appendChild(option);
      });
    })
    .catch((error) => console.error("Error fetching cities:", error));
});

document.addEventListener("DOMContentLoaded", function () {
  fetch(
    "http://localhost:8080/postbook/webapi/airbnb/properties/get-all-property-type"
  )
    .then((response) => response.json())
    .then((data) => {
      const cityFilter = document.getElementById("propertyTypeFilter");

      data.forEach((city) => {
        const option = document.createElement("option");
        option.value = city;
        option.text = city;
        cityFilter.appendChild(option);
      });
    })
    .catch((error) => console.error("Error fetching cities:", error));
});

async function searchOnInput() {
  const searchTerm = document
    .getElementById("propertyName")
    .value.toLowerCase();

  const items = await fetchAllProperties();

  const filteredItems = items.filter(
    (item) =>
      item.propertyTitle.toLowerCase().includes(searchTerm) ||
      item.propertyLocation.toLowerCase().includes(searchTerm)
  );

  appendPropertiesToContainer(feedContainer, filteredItems, true);
}

// async function filterByCity() {
//   const selectedCity = document.getElementById("cityFilter").value;
//   // console.log(selectedCity);
// const selectedType = document.getElementById("propertyTypeFilter").value;
//   const items = await fetchAllProperties();
//   // console.log('items',items);
//   const filteredItems = items
//     .filter(
//       (item) => item.propertyCity.toLowerCase() === selectedCity.toLowerCase()
//     )
//     .filter(
//       (item) => item.propertyType.toLowerCase() === selectedType.toLowerCase()
//     );
//   // console.log(filteredItems);

//   appendPropertiesToContainer(feedContainer, filteredItems, true);
// }

// async function filterByType() {

//   // console.log(selectedType);

//   const items = await fetchAllProperties();
//   // console.log('items',items);
//   const filteredItems = items.filter(
//     (item) => item.propertyType.toLowerCase() === selectedType.toLowerCase()
//   );
//   // console.log(filteredItems);

//   appendPropertiesToContainer(feedContainer, filteredItems, true);
// }

async function searchItems() {
  // Get the values from the input fields

  const items = await fetchAllProperties();

  const propertyName = document
    .getElementById("propertyName")
    .value.toLowerCase();
  const selectedCity = document
    .getElementById("cityFilter")
    .value.toLowerCase();
  const selectedType = document
    .getElementById("propertyTypeFilter")
    .value.toLowerCase();
  const priceRange =
    parseFloat(document.getElementById("priceRange").value) || 0;

  // Filter items based on multiple criteria
  const filteredItems = items.filter(
    (item) =>
      (propertyName === "" ||
        item.propertyTitle.toLowerCase().includes(propertyName)) &&
      (selectedCity === "" ||
        item.propertyCity.toLowerCase() === selectedCity) &&
      (selectedType === "" ||
        item.propertyType.toLowerCase() === selectedType) &&
      (priceRange === 0 || item.propertyPrice <= priceRange)
  );

  appendPropertiesToContainer(feedContainer, filteredItems, true);
}


 function signOutUser() {
   // ... (your sign-out logic) ...

   // After sign-out, hide the "Sign Out" button
   document.getElementById("sign-out-tab").style.display = "none";

   // Show the Sign In tab and set it as active
   document.getElementById("sign-in-tab").style.display = "list-item";
   document.getElementById("sign-in-tab").classList.add("active");

   // Hide the other tabs
   document.getElementById("sign-up-tab").style.display = "list-item";
   document.getElementById("profile-tab").disbaled = true;
   document.getElementById("my-tweets-tab").disabled = true;
 }