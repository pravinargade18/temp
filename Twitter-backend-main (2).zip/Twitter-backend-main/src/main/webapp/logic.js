let singedInUserId;
var signedInUser = null;
function addUser() {
  const url = "http://localhost:8080/postbook/webapi/twitter/users/add";

  const data = {
    userName: document.getElementById("signUpName").value,
    userEmail: document.getElementById("signUpEmail").value,
    userPassword: document.getElementById("signUpPassword").value,
  };
  document.getElementById("signUpName").value = "";
  document.getElementById("signUpEmail").value = "";
  document.getElementById("signUpPassword").value = "";

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => resp.json())
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}

let signedInUserEmail;

function signInUser() {
  const url = "http://localhost:8080/postbook/webapi/twitter/users/login";

  signedInUserEmail = document.getElementById("signInEmail").value;
  const data = {
    userEmail: document.getElementById("signInEmail").value,
    userPassword: document.getElementById("signInPassword").value,
  };

  document.getElementById("signInEmail").value = "";
  document.getElementById("signInPassword").value = "";

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => {
      if (!resp.ok) {
        throw new Error(`HTTP error! Status: ${resp.status}`);
      }
      return resp.json();
    })
    .then((responseData) => {
      signedInUser = responseData;
      console.log("resdata", responseData);
      singedInUserId = responseData.userId;
    })
    .catch((error) => {
      console.error("Error:", error);

      if (error.response) {
        error.response
          .text()
          .then((text) => console.log("Response text:", text));
      }
    });
}

function generateTweetCardsHTML(tweets, isMyTweetsTab) {
  let html = "";

  for (const tweet of tweets) {
    html += `
      <div class="card mb-3">
        <div class="card-body">
          <div class="d-flex align-items-center">
            <img src="${
              tweet.user.userAvatar
            }" alt="User Avatar" class="rounded-circle me-2" style="width: 50px; height: 50px;">
            <div>
              <h5 class="card-title mb-0">${tweet.user.userName}</h5>
              <p class="card-subtitle text-muted">${tweet.user.userEmail} • ${
      tweet.tweetId
    } minutes ago</p>
            </div>
          </div>
          <p class="card-text mt-3">${tweet.tweetBody}</p>
          <div class="d-flex justify-content-between align-items-center mt-3">
            <div>
              <button type="button" class="btn btn-outline-primary btn-sm"><i class="bi bi-chat"></i> 10</button>
              <button type="button" class="btn btn-outline-danger btn-sm" onclick="increaseTweetLike(${
                tweet.tweetId
              })"><i class="bi bi-heart"></i> ${tweet.tweetLikes}</button>
            </div>
            ${
              isMyTweetsTab
                ? `<button type="button" class="btn btn-outline-danger btn-sm" onclick="deleteTweet(${tweet.tweetId})">Delete</button>`
                : ""
            }
          </div>
        </div>
      </div>`;
  }

  return html;
}

function appendTweetsToContainer(container, tweets, isMyTweetsTab) {
  container.innerHTML = generateTweetCardsHTML(tweets, isMyTweetsTab);
}

async function getUser() {
  const url = "http://localhost:8080/postbook/webapi/twitter/users/getUser";
  const data = {
    userEmail: signedInUserEmail,
  };

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`Failed to get user. Status: ${response.status}`);
    }

    const responseData = await response.json();
    return responseData.userId;
  } catch (error) {
    console.error("Error getting user:", error);
    throw error; // Rethrow the error to propagate it
  }
}

async function fetchTweets() {
  try {
    console.log(signedInUserEmail);
    const userId = await getUser();
    console.log(userId);
    const response = await fetch(
      `http://localhost:8080/postbook/webapi/twitter/tweets/myTweet/${userId}`
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch tweets. Status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching tweets:", error);
    throw error; // Rethrow the error to propagate it
  }
}

const tweetsContainer = document.getElementById("tweetsContainer");

async function handleMyTweetsClick() {
  // console.log(signedInUserEmail);
  try {
    const tweetsData = await fetchTweets();
    appendTweetsToContainer(tweetsContainer, tweetsData, true);
  } catch (error) {
    // Handle errors here, e.g., display an error message to the user
    console.error("Error handling my tweets click:", error);
  }
}

async function fetchFeedTweets() {
  try {
    const response = await fetch(
      `http://localhost:8080/postbook/webapi/twitter/tweets/getAllTweet`
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch tweets. Status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching tweets:", error);
    throw error; // Rethrow the error to propagate it
  }
}

const feedContainer = document.getElementById("feedContainer");

// ... (other code)

async function handleAllTweetsClick() {
  try {
    const tweetsData = await fetchTweets();
    appendTweetsToContainer(feedContainer, tweetsData, true); // Use feedContainer instead of tweetsContainer
  } catch (error) {
    console.error("Error handling all tweets click:", error);
  }
}

// add tweet

function addTweet() {
  const url = "http://localhost:8080/postbook/webapi/twitter/tweets/add";

  const data = {
    tweetBody: document.getElementById("body").value,
    user: {
      userId: singedInUserId,
    },
  };

  document.getElementById("body").value = "";
  console.log(singedInUserId);

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((resp) => {
      handleAllTweetsClick();
      resp.json();
    })
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}

function increaseTweetLike(tweetId) {
  // console.log("new", signedInUser);
  const url = `http://localhost:8080/postbook/webapi/twitter/tweets/likes/${tweetId}`;

  fetch(url, { method: "PUT" })
    .then((resp) => {
      handleAllTweetsClick();
      handleMyTweetsClick();
      resp.json();
    })
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}

function deleteTweet(tweetId) {
  const url = `http://localhost:8080/postbook/webapi/twitter/tweets/deleteTweet/${tweetId}`;

  fetch(url, { method: "DELETE" })
    .then((resp) => {
      handleAllTweetsClick();
      handleMyTweetsClick();
      resp.json();
    })
    .then((responseData) => console.log(responseData))
    .catch((error) => console.error("Error:", error));
}


const profileTweetsContainer = document.getElementById(
  "profileTweetsContainer"
);

async function handleMyProfileTweetsClick() {
  try {
    const tweetsData = await fetchFeedTweets(); // Fetch all tweets instead of user's tweets
    appendTweetsToContainer(profileTweetsContainer, tweetsData, false); // Use false to indicate it's not the "My Tweets" tab
  } catch (error) {
    // Handle errors here, e.g., display an error message to the user
    console.error("Error handling profile tweets click:", error);
  }
}

 function makeEditable(fieldId) {
   const field = document.getElementById(fieldId);
   field.contentEditable = true;
   field.focus();
 }


function getProfile() {
  const profileContainer = document.getElementById("profileContainer");
  let html = "";

  html += `
  <!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Your Twitter</a>
    <!-- Add other navigation links or buttons -->
  </div>
</nav>

<!-- Profile Header -->
<div class="container mt-4">
  <div class="row">
    <div class="col-md-3">
      <!-- Profile Image -->
      <img src="${signedInUser.userAvatar}" alt="Profile Image" class="img-fluid rounded-circle profile-image" style="width: 150px; height: 150px;">
    </div>
    <div class="col-md-9">
      <!-- Profile Information -->
      <h2>${signedInUser.userName}</h2>
      <p>${signedInUser.userEmail}</p>
      <p class="editable" id="userBio" onclick="makeEditable('userBio')">${signedInUser.userBio}</p>
      <!-- Add other profile details -->

      <!-- Add Edit button for each editable field -->
      <button class="btn btn-link" onclick="makeEditable('userName')">Edit UserName</button>
      <button class="btn btn-link" onclick="makeEditable('userEmail')">Edit Email</button>
      <!-- Add more buttons as needed -->
    </div>
  </div>
</div>

<!-- Profile Tabs -->
<div class="container mt-4">
  <ul class="nav nav-tabs" id="myTabs" role="tablist">
    <li class="nav-item" role="presentation">
      <li class="nav-link active" id="tweets-tab" data-bs-toggle="tab" href="#tweets" role="tab" aria-controls="tweets"
        aria-selected="true" onclick="handleMyProfileTweetsClick()">Tweets</li>
    </li>
    <li class="nav-item" role="presentation">
      <a class="nav-link" id="media-tab" data-bs-toggle="tab" href="#media" role="tab" aria-controls="media"
        aria-selected="false">Media</a>
    </li>
    <!-- Add more tabs as needed -->
  </ul>

  <div class="tab-content mt-2" id="myTabsContent">
    <!-- Tweets Tab -->
    <div class="tab-pane fade show active" id="tweets" role="tabpanel" aria-labelledby="tweets-tab">
      <!-- Display user's tweets here -->
      <div id="profileTweetsContainer"></div>
    </div>

    <!-- Media Tab -->
    <div class="tab-pane fade" id="media" role="tabpanel" aria-labelledby="media-tab">
      <!-- Display user's media content here -->
      <p>Your media content will appear here.</p>
    </div>
    <!-- Add more tab content as needed -->
  </div>
</div>




     
  `;

  profileContainer.innerHTML = html;
}


